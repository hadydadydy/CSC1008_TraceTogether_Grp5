# CSC1008_TraceTogether_Grp5
CSC1008 TraceTogether Group 5

Before running program,

install following packages:

pip install pandas
pip install numpy
pip install parser
pip install datetime
pip install pyqt5
pip install folium
pip install graphviz

Ensure CloseContactList.py is in same directory as master.py

Thank you!